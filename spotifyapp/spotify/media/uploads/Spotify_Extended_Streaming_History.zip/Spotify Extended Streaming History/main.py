import json
from datetime import datetime

Função para converter milissegundos para minutos e segundos
def format_duration(ms):
    minutes = ms // 60000
    seconds = (ms % 60000) // 1000
    return f"{minutes}m {seconds}s"

Carregar dados do arquivo JSON
with open('Streaming_History_Audio_2023-2024_3.json', 'r') as file:
    data = json.load(file)

Processar e exibir os dados
for entry in data:
    timestamp = datetime.strptime(entry["ts"], "%Y-%m-%dT%H:%M:%SZ")
    duration = format_duration(entry["ms_played"])

    print(f"Artista: {entry['master_metadata_album_artist_name']}")
    print(f"Música: {entry['master_metadata_track_name']}")
    print(f"Álbum: {entry['master_metadata_album_album_name']}")
    print(f"Tocada em: {timestamp}")
    print(f"Duração: {duration}")
    print("-" * 40)